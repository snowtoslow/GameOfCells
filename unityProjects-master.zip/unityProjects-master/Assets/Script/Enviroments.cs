public enum Enviroments{

    TargarienRed,

    StarkGrey,

    LannisterYellow,

    FreePeopleBlue,
    
    None,
    
    DeadZone
}